# Cohen-Sutherland
Cohen-Sutherland线段裁剪算法的Three.js实现
![image](https://github.com/Meskjei/Cohen-Sutherland/blob/master/WX20181121-210639.png?raw=true)
